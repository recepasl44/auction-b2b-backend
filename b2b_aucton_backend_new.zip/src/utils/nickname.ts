export function generateNickname(): string {
  return `user-${Math.random().toString(36).substring(2, 8)}`;
}